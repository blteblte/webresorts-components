/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/YYPcyY
 */


importScripts("https://storage.googleapis.com/workbox-cdn/releases/3.0.0-alpha.3/workbox-sw.js");









/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "build/webresorts-components.js",
    "revision": "b6b7b5db4b8d7cd010b186d40ac95058"
  },
  {
    "url": "build/webresorts-components/u2hz6yti.es5.js",
    "revision": "ad85f7582e7618d777ef866eb31deea1"
  },
  {
    "url": "build/webresorts-components/u2hz6yti.js",
    "revision": "32deabd69c3824dfe39f45df59d9097b"
  },
  {
    "url": "build/webresorts-components/u2hz6yti.sc.es5.js",
    "revision": "926f3d0680e593999a3756a4da3f3397"
  },
  {
    "url": "build/webresorts-components/u2hz6yti.sc.js",
    "revision": "64b6b748e699b430f1509bf048fb1fe8"
  },
  {
    "url": "build/webresorts-components/webresorts-components.fiyj2mbs.js",
    "revision": "cb0ffff652530c85019a8106f36a00a2"
  },
  {
    "url": "build/webresorts-components/webresorts-components.registry.json",
    "revision": "89adcb931e4540a083fff2689648190b"
  },
  {
    "url": "build/webresorts-components/webresorts-components.zejpniqj.js",
    "revision": "cb314747885b90f5bba62a38ec99ca00"
  },
  {
    "url": "index.html",
    "revision": "c21f957d93ff61d09b5f816d6064e78b"
  }
].concat(self.__precacheManifest || []);

if (Array.isArray(self.__precacheManifest)) {
  workbox.precaching.suppressWarnings();
  workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
}
